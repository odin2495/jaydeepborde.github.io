
# Jaydeep Borde - Resume Website

This is an interactive resume website for Jaydeep Borde, featuring modern web design techniques and animations.

## Features

- Responsive design for all devices
- Interactive animations using AOS (Animate on Scroll)
- Parallax scrolling effect in the header
- 3D flip card for resume downloads
- Micro-interactions and hover effects
- Modern typography using Google Fonts

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- AOS (Animate on Scroll)
- Lucide React Icons
- ShadCN UI Components

## Setup Instructions

### Prerequisites

- Node.js (v14 or later)
- npm or yarn

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/username/jaydeep-resume.git
   cd jaydeep-resume
   ```

2. Install dependencies:
   ```
   npm install
   ```
   or
   ```
   yarn install
   ```

3. Start the development server:
   ```
   npm run dev
   ```
   or
   ```
   yarn dev
   ```

4. Open your browser and navigate to `http://localhost:5173`

## Build for Production

To build the project for production:

```
npm run build
```

or

```
yarn build
```

## Animation Details

- **Parallax Effect**: The header background moves at a different speed than the content when scrolling.
- **AOS Animations**: Elements fade in, zoom in, or slide in as they enter the viewport.
- **3D Flip Card**: The resume download card flips when hovered, revealing download options.
- **Hover Effects**: Various elements scale up, change color, or display additional information on hover.
- **Floating Elements**: Background shapes in the header that animate continuously.

## Customization

- Color scheme can be modified in the tailwind.config.ts file.
- Font styles can be changed by updating the Google Fonts import in index.css.
