
-- Create a function that will be called when a new contact is added
CREATE OR REPLACE FUNCTION public.handle_new_contact()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM
    net.http_post(
      url := 'https://pfhqtaacjnkqbtqkdwks.supabase.co/functions/v1/contact-notification',
      body := json_build_object('record', row_to_json(NEW)),
      headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBmaHF0YWFjam5rcWJ0cWtkd2tzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDcwMjMzNzIsImV4cCI6MjA2MjU5OTM3Mn0.-uWvfJks_pCCMONJeS0qYBcui3sT5kwMDCUAgJQLYQg"}'
    );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger that calls the function when a new contact is inserted
DROP TRIGGER IF EXISTS on_new_contact_trigger ON public.contacts;
CREATE TRIGGER on_new_contact_trigger
  AFTER INSERT ON public.contacts
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_contact();
