
import React, { useEffect } from 'react';
import AOS from 'aos'; // Import AOS library
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Profile from '../components/Profile';
import Experience from '../components/Experience';
import Skills from '../components/Skills';
import Education from '../components/Education';
import Personal from '../components/Personal';
import ContactInfo from '../components/ContactInfo';
import FloatingNav from '../components/FloatingNav';
import ResumeDownload from '../components/ResumeDownload';
import { ArrowLeft } from 'lucide-react';

const Index = () => {
  useEffect(() => {
    // Initialize AOS animation library
    AOS.init({
      duration: 800,
      once: false,
      mirror: true,
      offset: 100,
    });
    
    // Trigger reveal animations as user scrolls
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
        }
      });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('.reveal-animation').forEach(el => {
      observer.observe(el);
    });
    
    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* SEO Meta Tags */}
      <head>
        <title>Jaydeep P Borde | Cloud Computing & AWS Architecture</title>
        <meta name="description" content="AWS Solution Architect with expertise in Cloud Computing & AWS Architecture. Specialized in cloud infrastructure, deployment, and optimization." />
        <meta name="keywords" content="Jaydeep Borde, AWS, Cloud Computing, AWS Architecture, Cloud Engineer, AWS Solution Architect, DevOps" />
      </head>
      
      {/* Back to Landing Page Link */}
      <div className="fixed top-4 left-4 z-50">
        <Link 
          to="/" 
          className="flex items-center bg-white text-resume-primary px-4 py-2 rounded-full shadow-md hover:bg-resume-primary hover:text-white transition-all duration-300"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span className="text-sm font-medium">Back to Home</span>
        </Link>
      </div>
      
      <Header />
      
      <main>
        <Profile />
        <Experience />
        <Skills />
        <Education />
        <Personal />
        <ContactInfo />
        <ResumeDownload />
      </main>
      
      <footer className="bg-resume-primary text-white py-6 text-center text-sm">
        <div className="section-container">
          <p>&copy; {new Date().getFullYear()} Jaydeep P Borde. All rights reserved.</p>
          <Link to="/" className="text-blue-200 hover:text-white transition-colors mt-2 inline-block">
            Back to Home
          </Link>
        </div>
      </footer>
      
      <FloatingNav />
    </div>
  );
};

export default Index;
