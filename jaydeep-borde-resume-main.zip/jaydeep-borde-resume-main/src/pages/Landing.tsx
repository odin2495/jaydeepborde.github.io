import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import AOS from 'aos';
import { ArrowRight, Award, Cloud, Code, Download, Linkedin, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Landing = () => {
  useEffect(() => {
    // Initialize AOS animation library
    AOS.init({
      duration: 800,
      once: false,
      mirror: true,
      offset: 100,
    });
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-r from-blue-900 to-blue-700 text-white overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 z-0 opacity-10">
          <div className="absolute w-64 h-64 rounded-full bg-blue-600 opacity-20 top-[-100px] right-[-50px] animate-float"></div>
          <div className="absolute w-32 h-32 rounded-full bg-blue-300 opacity-10 bottom-[-20px] left-[20%] animate-float"></div>
          <div className="absolute w-48 h-48 rounded-full bg-blue-800 opacity-15 top-[30%] left-[-80px] animate-float"></div>
        </div>
        
        {/* Floating Particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(10)].map((_, i) => (
            <div 
              key={i}
              className="absolute w-2 h-2 bg-white rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.5 + 0.3,
                animation: `float ${Math.random() * 10 + 5}s infinite ease-in-out`,
                animationDelay: `${Math.random() * 5}s`
              }}
            ></div>
          ))}
        </div>

        <div className="container px-4 z-10 max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2" data-aos="fade-right">
              <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-3">
                Jaydeep P Borde
              </h1>
              <div className="h-1 w-24 bg-resume-secondary mb-6"></div>
              <h2 className="text-2xl md:text-3xl text-blue-200 mb-6">
                AWS Solution Architect
              </h2>
              <p className="text-lg md:text-xl mb-8 max-w-lg">
                An achievement-driven Cloud Professional with expertise in 
                <span className="font-semibold bg-gradient-to-r from-blue-100 to-blue-300 text-transparent bg-clip-text"> AWS Architecture & DevOps </span>
                targeting challenging assignments with organizations of repute.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Link to="/resume">
                  <Button className="bg-white text-blue-900 hover:bg-blue-50 text-base px-6 py-6">
                    View My Resume
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <a href="#highlights">
                  <Button variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-blue-900 text-base px-6 py-6">
                    Discover More
                  </Button>
                </a>
              </div>
            </div>
            
            <div className="md:w-1/2 mt-10 md:mt-0" data-aos="fade-left" data-aos-delay="200">
              {/* The rotating card has been removed from here */}
            </div>
          </div>
        </div>
      </section>

      {/* Highlights Section */}
      <section id="highlights" className="py-20 bg-white">
        <div className="container px-4 max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16" data-aos="fade-up">
            Professional Highlights
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "AWS Architecture",
                description: "Expert in designing and implementing fault-tolerant, scalable systems on AWS infrastructure",
                icon: <Cloud className="h-8 w-8 text-resume-primary" />,
                delay: 100
              },
              {
                title: "Cloud Operations",
                description: "Experienced in managing and optimizing cloud infrastructure for performance and cost efficiency",
                icon: <Code className="h-8 w-8 text-resume-primary" />,
                delay: 200
              },
              {
                title: "DevOps Practices",
                description: "Skilled in implementing CI/CD pipelines and infrastructure as code for automated deployments",
                icon: <Award className="h-8 w-8 text-resume-primary" />,
                delay: 300
              }
            ].map((item, idx) => (
              <div 
                key={idx} 
                className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300"
                data-aos="fade-up"
                data-aos-delay={item.delay}
              >
                <div className="bg-blue-100 p-3 rounded-full inline-block mb-4">
                  {item.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center" data-aos="fade-up" data-aos-delay="400">
            <Link to="/resume">
              <Button className="bg-resume-primary text-white hover:bg-resume-primary/90 text-base px-8 py-6">
                View My Full Resume
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-blue-900 to-blue-700 text-white">
        <div className="container px-4 max-w-6xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { number: "3+", label: "Years Experience" },
              { number: "15+", label: "AWS Services" },
              { number: "20+", label: "Projects Delivered" },
              { number: "100%", label: "Client Satisfaction" }
            ].map((stat, idx) => (
              <div key={idx} data-aos="fade-up" data-aos-delay={idx * 100}>
                <div className="text-4xl md:text-5xl font-bold mb-2">{stat.number}</div>
                <div className="text-blue-200">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container px-4 max-w-6xl mx-auto">
          <div className="bg-gray-50 rounded-lg p-8 md:p-12 flex flex-col md:flex-row items-center justify-between shadow-sm" data-aos="fade-up">
            <div className="md:w-2/3 mb-6 md:mb-0">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to collaborate?</h2>
              <p className="text-gray-600 mb-4 md:mb-0 max-w-lg">
                Looking for an AWS expert to help with your cloud infrastructure or migration? 
                Let's connect and discuss how I can contribute to your project's success.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="mailto:jaydeepborde734@gmail.com">
                <Button className="bg-resume-primary text-white hover:bg-resume-primary/90 px-6 py-3 flex items-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Contact Me
                </Button>
              </a>
              <a href="https://www.linkedin.com/in/jaydeep-borde-a2b132189" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="border-resume-primary text-resume-primary hover:bg-resume-primary/10 px-6 py-3 flex items-center">
                  <Linkedin className="mr-2 h-5 w-5" />
                  LinkedIn
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container px-4 max-w-6xl mx-auto text-center">
          <p>&copy; {new Date().getFullYear()} Jaydeep P Borde. All rights reserved.</p>
          <div className="mt-4">
            <Link to="/resume" className="text-blue-300 hover:text-blue-100 transition-colors mx-3">Resume</Link>
            <a href="mailto:jaydeepborde734@gmail.com" className="text-blue-300 hover:text-blue-100 transition-colors mx-3">Contact</a>
            <a href="https://www.linkedin.com/in/jaydeep-borde-a2b132189" target="_blank" rel="noopener noreferrer" className="text-blue-300 hover:text-blue-100 transition-colors mx-3">LinkedIn</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
