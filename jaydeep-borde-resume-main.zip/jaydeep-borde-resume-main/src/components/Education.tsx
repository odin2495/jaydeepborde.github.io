
import React from 'react';
import { Book, Award } from 'lucide-react';

const Education = () => {
  return (
    <section id="education" className="py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="section-container">
        <h2 className="section-title" data-aos="fade-right">
          <Book className="section-icon" />
          EDUCATION
        </h2>
        
        <div className="group bg-white rounded-lg shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden" data-aos="fade-up" data-aos-delay="200">
          <div className="relative overflow-hidden">
            {/* Decorative gradient header */}
            <div className="h-8 bg-gradient-to-r from-blue-800 to-blue-600"></div>
            <div className="absolute top-2 right-2 w-16 h-16">
              <div className="bg-resume-secondary text-white rounded-full w-full h-full flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-300">
                <Award className="w-8 h-8" />
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="flex flex-col md:flex-row items-start justify-between">
              <div className="flex items-center mb-4 md:mb-0">
                <div className="bg-blue-50 p-3 rounded-full mr-4">
                  <Book className="text-resume-primary h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold group-hover:text-resume-primary transition-colors">Bachelor of Engineering (Information Technology)</h3>
                  <p className="text-gray-600">Pimpri Chinchwad College of Engineering, Pune</p>
                </div>
              </div>
              <div className="md:text-right">
                <div className="inline-flex items-center bg-blue-50 px-4 py-2 rounded-lg group-hover:bg-resume-primary group-hover:text-white transition-colors">
                  <span className="font-semibold">7.8 CGPA</span>
                </div>
                <p className="text-gray-600 mt-1">Graduation: 2023</p>
              </div>
            </div>
            
            {/* Additional education details with animation */}
            <div className="mt-6 border-t border-gray-100 pt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
              <p className="text-gray-700">
                <span className="font-medium">Key Courses:</span> Cloud Computing, Data Structures, Database Management Systems, 
                Computer Networks, Operating Systems, Web Technologies
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
