
import React from 'react';
import { Briefcase } from 'lucide-react';

const Experience = () => {
  return (
    <section id="experience" className="py-12 bg-gray-50">
      <div className="section-container">
        <h2 className="section-title reveal-animation animate-fade-in" style={{ '--delay': '200ms' } as React.CSSProperties}>
          <Briefcase className="section-icon" />
          WORK EXPERIENCE
        </h2>
        
        <div className="bg-white rounded-lg p-6 shadow-sm mb-8 reveal-animation animate-fade-in" style={{ '--delay': '400ms' } as React.CSSProperties}>
          <div className="flex flex-col md:flex-row md:justify-between mb-4">
            <h3 className="text-xl font-semibold text-resume-primary">Cloud Operations Engineer & Cloud Support Associate at Microspark Software Solutions, Hyderabad</h3>
            <span className="text-resume-secondary font-medium">Since June 2022</span>
          </div>
          
          <div className="mb-6">
            <h4 className="text-lg font-medium mb-2">Growth Path:</h4>
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
              <div className="flex items-center">
                <div className="bg-resume-secondary text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
                  <span className="text-sm">1</span>
                </div>
                <div>
                  <p className="font-medium">Internship</p>
                  <p className="text-sm text-gray-600">(June 22 - 23)</p>
                </div>
              </div>
              <div className="hidden md:block">→</div>
              <div className="flex items-center">
                <div className="bg-resume-secondary text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
                  <span className="text-sm">2</span>
                </div>
                <div>
                  <p className="font-medium">Cloud Support Associate</p>
                  <p className="text-sm text-gray-600">(June 23 - Oct 24)</p>
                </div>
              </div>
              <div className="hidden md:block">→</div>
              <div className="flex items-center">
                <div className="bg-resume-accent text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
                  <span className="text-sm">3</span>
                </div>
                <div>
                  <p className="font-medium">Cloud Operation Engineer</p>
                  <p className="text-sm text-gray-600">(Oct 24 - Present)</p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-3">Key Result Areas:</h4>
            <ul className="space-y-3">
              <li className="bullet-item">Migrating the on-premises to AWS using Cloudendure Tool.</li>
              <li className="bullet-item">Working on different AWS services like EC2, VPC, S3, ALB, Autoscaling, RDS, Cloudwatch, Cloudtrail, Resdis, ACM, Route53, KMS, Cloudformation</li>
              <li className="bullet-item">Launching Amazon EC2 cloud instance using Amazon Web Services (Linux) and further configuring launched instances with respect to specific crucial applications</li>
              <li className="bullet-item">Designing, and implementing next generation of cloud-based applications which are dynamically scalable, fault tolerant, secure & reliable</li>
              <li className="bullet-item">Creating users and groups using IAM and assigning individual policies to each group; maintaining the security group and setting up rules for instances that are associated with security group</li>
              <li className="bullet-item">Modifying and adding routes in Route53; taking AMI/Snapshot backups and restoring from snapshots in case of failure</li>
              <li className="bullet-item">Producing new buckets and giving proper access by creating policies in IAM; installing and configuring packages using YUM and RPM</li>
              <li className="bullet-item">Defining scope, requirements analysis, functional & technical design, application build, product configuration, unit testing, and production deployment</li>
              <li className="bullet-item">Ensuring delivered solutions meet/perform to technical and functional/non-functional requirements</li>
            </ul>
            
            <div className="mt-6">
              <h4 className="text-lg font-medium mb-2">Highlights:</h4>
              <ul className="space-y-3">
                <li className="bullet-item">Consolidated the findings from the analysis and presented effective solutions to the client</li>
                <li className="bullet-item">Successfully designed and executed end-to-end cloud implementations for the organization</li>
                <li className="bullet-item">Gained strong understanding of network architecture and application development methodologies along with SOA, object-oriented analysis & design, and client/server systems</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-6 shadow-sm reveal-animation animate-fade-in" style={{ '--delay': '600ms' } as React.CSSProperties}>
          <div className="flex flex-col md:flex-row md:justify-between mb-4">
            <h3 className="text-xl font-semibold text-resume-primary">Intern at Microspark Software Solutions, Hyderabad</h3>
            <span className="text-resume-secondary font-medium">June 2022 – June 2023</span>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-3">Key Result Areas:</h4>
            <ul className="space-y-3">
              <li className="bullet-item">Monitored and troubleshot Linux/Windows servers & L1 level issues hosted on AWS cloud</li>
              <li className="bullet-item">Contributed in client engagement, critically towards well-defined purposes and achievement standards</li>
              <li className="bullet-item">Identified AWS market requirement, client base, and corporate requirements; dealt with customers via tickets & calls to resolve issues related to Linux & AWS</li>
              <li className="bullet-item">Installed CloudWatch agent on Linux servers and monitored the infrastructure; ensured necessary system security by using best-in-class cloud security solutions</li>
              <li className="bullet-item">Updated with new technology options & vendor products and evaluated which ones would be an ideal fit for the company</li>
              <li className="bullet-item">Administered and monitored system performance, disc space and memory</li>
            </ul>
            
            <div className="mt-6">
              <h4 className="text-lg font-medium mb-2">Highlights:</h4>
              <ul className="space-y-3">
                <li className="bullet-item">Monitored logs for better understanding the functioning of systems; set up and managed EBS volumes & EIP to EC2 instances</li>
                <li className="bullet-item">Created, maintained, and evolved an AWS cloud infrastructure for running applications</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
