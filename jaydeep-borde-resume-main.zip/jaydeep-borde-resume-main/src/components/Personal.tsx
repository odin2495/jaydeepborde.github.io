
import React from 'react';
import { User, CalendarIcon, MapPin } from 'lucide-react';

const Personal = () => {
  return (
    <section id="personal" className="py-12 bg-white">
      <div className="section-container">
        <h2 className="section-title reveal-animation animate-fade-in" style={{ '--delay': '200ms' } as React.CSSProperties}>
          <User className="section-icon" />
          PERSONAL DETAILS
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 reveal-animation animate-fade-in" style={{ '--delay': '400ms' } as React.CSSProperties}>
          <div className="bg-blue-50 rounded-lg p-5 shadow-sm">
            <div className="flex items-center mb-4">
              <CalendarIcon className="text-resume-primary mr-3 h-5 w-5" />
              <h3 className="font-semibold">Date of Birth</h3>
            </div>
            <p className="text-gray-700 ml-8">18th June 1999</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-5 shadow-sm">
            <div className="flex items-center mb-4">
              <svg className="text-resume-primary mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <h3 className="font-semibold">Languages Known</h3>
            </div>
            <p className="text-gray-700 ml-8">English, Hindi & Marathi</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-5 shadow-sm">
            <div className="flex items-center mb-4">
              <svg className="text-resume-primary mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                <line x1="9" y1="9" x2="9.01" y2="9"></line>
                <line x1="15" y1="9" x2="15.01" y2="9"></line>
              </svg>
              <h3 className="font-semibold">Hobbies</h3>
            </div>
            <p className="text-gray-700 ml-8">Traveling, Bike Riding, Football, Table Tennis</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-5 shadow-sm">
            <div className="flex items-center mb-4">
              <MapPin className="text-resume-primary mr-3 h-5 w-5" />
              <h3 className="font-semibold">Address</h3>
            </div>
            <p className="text-gray-700 ml-8">Opposite As club hotel, Aurangabad, Maharashtra</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Personal;
