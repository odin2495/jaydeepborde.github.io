
import React from 'react';
import { User } from 'lucide-react';

const Profile = () => {
  return (
    <section id="profile" className="py-12 bg-white">
      <div className="section-container">
        <h2 className="section-title reveal-animation animate-fade-in" style={{ '--delay': '200ms' } as React.CSSProperties}>
          <User className="section-icon" />
          PROFILE SUMMARY
        </h2>
        
        <div className="bg-gray-50 rounded-lg p-6 shadow-sm reveal-animation animate-fade-in" style={{ '--delay': '400ms' } as React.CSSProperties}>
          <ul className="space-y-4">
            <li className="bullet-item">
              A result-oriented professional, <span className="font-semibold">AWS Solution Architect – Associate</span> with 
              <span className="font-semibold"> nearly 3 years</span> of experience in <span className="font-semibold">Cloud Computing & AWS Architecture</span>; 
              currently employed as <span className="font-semibold">Cloud Operation Engineer</span> at <span className="font-semibold">MicroSpark Software Solution Pvt. Ltd</span>
            </li>
            <li className="bullet-item">
              Acted as a primary technical associate of Technical Team in assisting in confirming customer success in creating applications and services on the AWS platform
            </li>
            <li className="bullet-item">
              Possess technical background and assisted in ensuring a suitable & successful delivery of agreed cloud services
            </li>
            <li className="bullet-item">
              Created, maintained, and evolved an AWS cloud infrastructure for running multiple applications
            </li>
            <li className="bullet-item">
              Supported creation & maintenance of development, test & production environments with a goal of high availability, fault-tolerance and scalability
            </li>
            <li className="bullet-item">
              Drove the timely deployment of updates and fixes; provided level 1 technical support, as necessary
            </li>
            <li className="bullet-item">
              Developed monitoring tools for observing testing progress and overall product health
            </li>
            <li className="bullet-item">
              Performed root cause analysis for production errors; investigated and resolved technical issues
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Profile;
