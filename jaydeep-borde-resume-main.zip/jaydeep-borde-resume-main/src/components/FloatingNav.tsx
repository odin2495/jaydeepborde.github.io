
import React, { useState, useEffect } from 'react';
import { 
  User, 
  Briefcase, 
  Code, 
  Book, 
  MapPin, 
  Phone,
  Download
} from 'lucide-react';

const FloatingNav = () => {
  const [activeSection, setActiveSection] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const [isCompact, setIsCompact] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show floating nav after scrolling past header
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }

      // Switch to compact mode on deep scroll
      if (window.scrollY > 1200) {
        setIsCompact(true);
      } else {
        setIsCompact(false);
      }

      // Determine active section
      const sections = ['profile', 'experience', 'skills', 'education', 'personal', 'contact'];
      let current = '';

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 150 && rect.bottom >= 150) {
            current = section;
            break;
          }
        }
      }

      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 100,
        behavior: 'smooth'
      });
    }
  };

  if (!isVisible) return null;

  const navItems = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'experience', label: 'Experience', icon: Briefcase },
    { id: 'skills', label: 'Skills', icon: Code },
    { id: 'education', label: 'Education', icon: Book },
    { id: 'personal', label: 'Personal', icon: MapPin },
    { id: 'contact', label: 'Contact', icon: Phone },
  ];

  return (
    <div className={`fixed ${isCompact ? 'bottom-4 right-4' : 'bottom-8 left-1/2 transform -translate-x-1/2'} z-50 animate-fade-in transition-all duration-300`}>
      {isCompact ? (
        <div className="bg-resume-primary text-white rounded-full p-3 shadow-lg pulse-border cursor-pointer" onClick={() => setIsCompact(false)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </div>
      ) : (
        <div className="bg-white shadow-lg rounded-full py-3 px-4 backdrop-blur-md bg-opacity-95 border border-gray-200">
          <div className="flex space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button 
                  key={item.id}
                  onClick={() => scrollTo(item.id)} 
                  className={`flex items-center rounded-full transition-all duration-300 ${
                    activeSection === item.id 
                      ? 'bg-resume-primary text-white px-4 py-1' 
                      : 'text-gray-500 hover:text-resume-primary px-2 py-1'
                  }`}
                >
                  <Icon size={18} />
                  {activeSection === item.id && (
                    <span className="ml-2 text-sm font-medium">{item.label}</span>
                  )}
                </button>
              );
            })}
            <a 
              href="#" 
              onClick={() => scrollTo('download')} 
              className="flex items-center text-gray-500 hover:text-resume-primary px-2 py-1 rounded-full transition-all duration-300"
              title="Download Resume"
            >
              <Download size={18} />
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default FloatingNav;
