import React, { useState } from 'react';
import { Phone, Mail, Linkedin, Github } from 'lucide-react';
import { supabase } from "@/integrations/supabase/client";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/sonner";
import { Textarea } from "@/components/ui/textarea";

// Define form schema
const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  subject: z.string().min(5, { message: "Subject must be at least 5 characters." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." })
});

// Make this type match the exact structure Supabase expects
type ContactFormValues = {
  name: string;
  email: string;
  subject: string;
  message: string;
};

const ContactInfo = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize form
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: ""
    }
  });

  // Handle form submission
  const onSubmit = async (data: ContactFormValues) => {
    setIsSubmitting(true);

    try {
      // Insert the contact form data into Supabase
      const { error } = await supabase
        .from('contacts')
        .insert(data);

      if (error) {
        console.error("Error submitting form:", error);
        throw new Error(error.message);
      }

      // Show success message
      toast.success("Message sent successfully! We'll get back to you soon.");
      form.reset();
    } catch (error) {
      console.error("Form submission error:", error);
      toast.error("Failed to send message. Please try again later.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="section-container">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-2 text-resume-primary" data-aos="fade-up">Get In Touch</h2>
          <div className="w-16 h-1 bg-resume-secondary mx-auto mb-6" data-aos="fade-up" data-aos-delay="100"></div>
          <p className="text-lg mb-10 text-gray-600" data-aos="fade-up" data-aos-delay="200">
            Feel free to reach out for opportunities or collaborations
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <a 
              href="tel:+919922030781" 
              className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-xl transition-all duration-300"
              data-aos="zoom-in" 
              data-aos-delay="300"
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-resume-primary transition-colors">
                <Phone className="h-7 w-7 text-resume-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-semibold mb-1 group-hover:text-resume-primary transition-colors">Phone</h3>
              <span className="text-gray-700 block">+91-9922030781</span>
            </a>
            
            <a 
              href="mailto:jaydeepborde734@gmail.com" 
              className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-xl transition-all duration-300"
              data-aos="zoom-in" 
              data-aos-delay="400"
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-resume-primary transition-colors">
                <Mail className="h-7 w-7 text-resume-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-semibold mb-1 group-hover:text-resume-primary transition-colors">Email</h3>
              <span className="text-gray-700 block">jaydeepborde734@gmail.com</span>
            </a>
            
            <a 
              href="https://www.linkedin.com/in/jaydeep-borde-a2b132189" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-xl transition-all duration-300"
              data-aos="zoom-in" 
              data-aos-delay="500"
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-resume-primary transition-colors">
                <Linkedin className="h-7 w-7 text-resume-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-semibold mb-1 group-hover:text-resume-primary transition-colors">LinkedIn</h3>
              <span className="text-gray-700 block">Connect with me</span>
            </a>
            
            <a 
              href="https://github.com/jaydeepborde" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-xl transition-all duration-300"
              data-aos="zoom-in" 
              data-aos-delay="600"
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-resume-primary transition-colors">
                <Github className="h-7 w-7 text-resume-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-semibold mb-1 group-hover:text-resume-primary transition-colors">GitHub</h3>
              <span className="text-gray-700 block">Check my repos</span>
            </a>
          </div>
          
          <div className="mt-16" data-aos="fade-up" data-aos-delay="700">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="max-w-lg mx-auto space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="Your Name" 
                            {...field} 
                            className="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="Your Email" 
                            {...field} 
                            className="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input 
                          placeholder="Subject" 
                          {...field} 
                          className="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea 
                          placeholder="Your Message" 
                          {...field} 
                          rows={4}
                          className="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-resume-primary text-white font-medium px-6 py-3 rounded-lg transition-all hover:bg-resume-primary/80 hover:-translate-y-1 hover:shadow-lg w-full sm:w-auto"
                >
                  {isSubmitting ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactInfo;
