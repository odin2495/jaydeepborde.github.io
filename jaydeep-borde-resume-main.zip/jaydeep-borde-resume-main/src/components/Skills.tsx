
import React from 'react';
import { Code } from 'lucide-react';

const Skills = () => {
  const coreCompetencies = [
    "AWS Cloud Architecture",
    "Quality Assurance",
    "Requirement Gathering",
    "Technical Support",
    "Migration & Deployment",
    "Team Coordination",
    "Performance Tuning & Optimization"
  ];

  const technicalSkills = [
    { category: "Container Services", skills: ["Docker", "ECS"] },
    { category: "Cloud Computing", skills: ["AWS", "Azure"] },
    { category: "Database", skills: ["MySQL", "Maria DB"] },
    { category: "Operating System", skills: ["Linux (RedHat, Centos, Ubuntu, Amazon Linux)"] },
    { category: "Ticketing Tool", skills: ["Jira", "OTRS", "OpsRamp"] },
    { category: "Provisioning Tools", skills: ["Terraform", "CloudFormation"] },
    { category: "Monitoring Tools", skills: ["Zabbix", "Grafana", "Newrelic"] },
  ];

  const serviceUsage = [
    "EC2", "VPC", "S3", "ALB", "Autoscaling", "RDS", "CloudWatch", 
    "CloudTrail", "Redis", "ACM", "Route53", "KMS", "CloudFormation", "IAM"
  ];
  
  const getRandomDelay = () => Math.floor(Math.random() * 500) + 100;

  return (
    <section id="skills" className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h2 className="section-title" data-aos="fade-right">
              <Code className="section-icon" />
              CORE COMPETENCIES
            </h2>
            
            <div className="flex flex-wrap gap-4">
              {coreCompetencies.map((skill, index) => (
                <div 
                  key={index} 
                  className="bg-gradient-to-r from-blue-50 to-blue-100 border-l-4 border-resume-primary px-4 py-3 rounded-md shadow-sm transition-all hover:shadow-md hover:-translate-y-1"
                  data-aos="zoom-in"
                  data-aos-delay={100 * (index + 1)}
                >
                  <span className="font-medium text-resume-dark">{skill}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h2 className="section-title" data-aos="fade-left">
              <Code className="section-icon" />
              TECHNICAL SKILLS
            </h2>
            
            <div className="space-y-4">
              {technicalSkills.map((category, index) => (
                <div 
                  key={index} 
                  className="bg-white rounded-lg p-4 shadow-sm hover-lift"
                  data-aos="fade-up"
                  data-aos-delay={100 * (index + 1)}
                >
                  <h3 className="font-semibold text-resume-primary mb-2">{category.category}:</h3>
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill, skillIndex) => (
                      <span 
                        key={skillIndex} 
                        className="skill-pill"
                        data-aos="zoom-in"
                        data-aos-delay={getRandomDelay()}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-12" data-aos="fade-up" data-aos-delay="200">
          <h2 className="section-title">
            <Code className="section-icon" />
            SERVICES USAGE
          </h2>
          
          <div className="bg-gradient-to-r from-blue-800 to-blue-600 rounded-lg p-6 shadow-lg text-white">
            <div className="flex flex-wrap gap-3">
              {serviceUsage.map((service, index) => (
                <span 
                  key={index} 
                  className="bg-blue-700 bg-opacity-50 px-3 py-1 rounded-full border border-blue-400 text-sm inline-block transition-all hover:bg-blue-600 hover:scale-110 hover:shadow-md"
                  data-aos="zoom-in"
                  data-aos-delay={50 * (index + 1)}
                >
                  {service}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
