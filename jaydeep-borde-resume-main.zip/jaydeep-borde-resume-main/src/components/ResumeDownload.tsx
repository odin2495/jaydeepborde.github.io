
import React from 'react';
import { Download, Linkedin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const ResumeDownload = () => {
  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="section-container">
        <div className="max-w-3xl mx-auto" data-aos="fade-up">
          <Card className="overflow-hidden transform transition-all hover:-translate-y-2 hover:shadow-xl">
            <div className="flip-card h-64">
              <div className="flip-card-inner">
                <div className="flip-card-front bg-gradient-to-r from-blue-800 to-blue-600 text-white flex flex-col items-center justify-center p-8 text-center">
                  <h3 className="text-2xl font-bold mb-4">Want a copy of my resume?</h3>
                  <p className="mb-6">Hover over this card to see download options</p>
                  <div className="animate-bounce">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  </div>
                </div>
                <div className="flip-card-back bg-white flex flex-col items-center justify-center p-8 text-center">
                  <h3 className="text-2xl font-bold text-resume-primary mb-4">Download Options</h3>
                  <div className="flex flex-col space-y-4 w-full max-w-xs">
                    <Button 
                      variant="default"
                      className="bg-resume-primary text-white hover:bg-resume-primary/90 flex items-center justify-center gap-2 w-full"
                      onClick={() => window.open('/resume-jaydeep-borde.pdf')}
                    >
                      <Download size={18} />
                      PDF Format
                    </Button>
                    
                    <Button 
                      variant="outline"
                      className="border-resume-primary text-resume-primary hover:bg-resume-primary/10 flex items-center justify-center gap-2 w-full"
                      onClick={() => window.open('/resume-jaydeep-borde.docx')}
                    >
                      <Download size={18} />
                      Word Format
                    </Button>
                    
                    <a 
                      href="https://www.linkedin.com/in/jaydeep-borde-a2b132189" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 text-sm text-resume-primary hover:underline mt-2"
                    >
                      <Linkedin size={16} />
                      Visit my LinkedIn Profile
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ResumeDownload;
