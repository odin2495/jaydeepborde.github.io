
import React, { useEffect, useState } from 'react';
import { Phone, Mail, Download, Linkedin, Github } from 'lucide-react';

const Header = () => {
  // State to track scroll position for parallax effect
  const [scrollY, setScrollY] = useState(0);

  // Setup scroll event handler for parallax effect
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className="relative h-[650px] md:h-[600px] lg:h-[550px] overflow-hidden bg-gradient-to-r from-blue-900 to-blue-700 text-white">
      {/* Parallax background with subtle pattern */}
      <div 
        className="absolute inset-0 z-0 opacity-10"
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.4"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
          transform: `translateY(${scrollY * 0.4}px)` // Parallax effect
        }}
      />
      
      {/* Floating circles for visual interest */}
      <div className="absolute w-64 h-64 rounded-full bg-blue-600 opacity-20 top-[-100px] right-[-50px] animate-float" style={{ animationDelay: '0s' }}></div>
      <div className="absolute w-32 h-32 rounded-full bg-blue-300 opacity-10 bottom-[-20px] left-[20%] animate-float" style={{ animationDelay: '1s' }}></div>
      <div className="absolute w-48 h-48 rounded-full bg-blue-800 opacity-15 top-[30%] left-[-80px] animate-float" style={{ animationDelay: '2s' }}></div>
      
      {/* Content Container */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 py-16 h-full flex flex-col justify-center">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between rounded-none">
          <div className="mb-10 md:mb-0" data-aos="fade-right" data-aos-delay="100" data-aos-duration="800">
            <h1 className="text-5xl md:text-6xl font-bold mb-2 text-shadow">
              Jaydeep P Borde
              <div className="h-1 w-24 bg-resume-secondary mt-3 mb-4"></div>
            </h1>
            <p className="text-2xl text-blue-200 mb-6">Cloud Computing & Architecture</p>
            
            <div className="mt-4">
              <p className="mb-3 text-base lg:text-lg">
                An achievement-driven IT professional with a focus on <br className="hidden md:inline" />
                <span className="font-semibold bg-gradient-to-r from-blue-100 to-blue-300 text-transparent bg-clip-text">Cloud Computing & AWS Architecture</span>; targeting
                challenging assignments with an organization of repute
              </p>
            </div>
            
            {/* CTA buttons with hover effects */}
            <div className="mt-8 flex flex-wrap gap-4">
              <a 
                href="#contact" 
                className="bg-white text-blue-900 px-6 py-3 rounded-full font-medium transition-all hover:bg-blue-50 hover:-translate-y-1 hover:shadow-lg inline-flex items-center"
              >
                Contact Me
                <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
              
              <a 
                href="#skills" 
                className="border-2 border-white text-white px-6 py-3 rounded-full font-medium transition-all hover:bg-white hover:text-blue-900 hover:-translate-y-1 hover:shadow-lg"
              >
                View Skills
              </a>
            </div>
          </div>
          
          <div className="md:text-right" data-aos="fade-left" data-aos-delay="300" data-aos-duration="800">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm p-5 rounded-xl border border-white border-opacity-20 hover:bg-opacity-20 transition-all glow-on-hover">
              <div className="flex flex-col space-y-4">
                <a href="tel:+919922030781" className="flex items-center text-blue-100 hover:text-white transition-colors group">
                  <Phone className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                  <span>+91-9922030781</span>
                </a>
                <a href="mailto:jaydeepborde734@gmail.com" className="flex items-center text-blue-100 hover:text-white transition-colors group">
                  <Mail className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                  <span>jaydeepborde734@gmail.com</span>
                </a>
                <a href="https://www.linkedin.com/in/jaydeep-borde-a2b132189" target="_blank" rel="noopener noreferrer" className="flex items-center text-blue-100 hover:text-white transition-colors group">
                  <Linkedin className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                  <span>LinkedIn</span>
                </a>
                <a href="#" className="flex items-center text-blue-100 hover:text-white transition-colors group">
                  <Github className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                  <span>GitHub</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
